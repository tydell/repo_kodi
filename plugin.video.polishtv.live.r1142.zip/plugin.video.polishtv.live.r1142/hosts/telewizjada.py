# -*- coding: utf-8 -*-
import os, sys
import xbmcaddon
import traceback, urllib

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json

scriptID = 'plugin.video.polishtv.live'
scriptname = "Polish Live TV"
ptv = xbmcaddon.Addon(scriptID)

BASE_IMAGE_PATH = 'http://sd-xbmc.org/repository/xbmc-addons/'
BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()

SERVICE = 'telewizjada'
LOGOURL = BASE_IMAGE_PATH + SERVICE + '.png'
MAINURL = 'http://www.telewizjada.net/'
COOKIEFILE = ptv.getAddonInfo('path') + os.path.sep + "cookies" + os.path.sep + SERVICE +".cookie"

class telewizjada:
    def __init__(self):
        log.info('Loading ' + SERVICE)
        self.parser = sdParser.Parser()
        self.exception = sdErrors.Exception()
        self.gui = sdNavigation.sdGUI()
        self.common = sdCommon.common()


    def listChannels(self):     
	query_data = { 'url': MAINURL + 'get_channels.php', 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
        
	try:
	    data = self.common.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	    
        result = _json.loads(data)
        for item in result['channels']:
            params = {'service': SERVICE, 'id': item['id'], 'title': item['displayName'].encode('utf-8'), 'icon': MAINURL + item['bigThumb']}
	    self.gui.addDir(params)
	self.gui.endDir()

        
    def getVideoUrl(self, id):
	query_data = { 'url': MAINURL + 'get_mainchannel.php', 'use_host': False, 'use_cookie': False, 'use_post': True, 'return_data': True}
        post_data = { 'cid': id }
	try:
	    data = self.common.getURLRequestData(query_data, post_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	result = _json.loads(data)

	query_data = { 'url': MAINURL + 'set_cookie.php', 'use_host': False,  'use_cookie': True, 'load_cookie': False, 'save_cookie': True, 'cookiefile': COOKIEFILE, 'use_post': True, 'return_data': True}
        post_data = { 'url': result['url'] }

	try:
	    data = self.common.getURLRequestData(query_data, post_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	
	query_data = { 'url': MAINURL + 'get_channel_url.php', 'use_host': False,  'use_cookie': True, 'load_cookie': True, 'save_cookie': False, 'cookiefile': COOKIEFILE, 'use_post': True, 'return_data': True}
        post_data = { 'cid': id }
	try:
	    data = self.common.getURLRequestData(query_data, post_data)
	    result = _json.loads(data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	return result['url']
	    

    def handleService(self):
        params = self.parser.getParams()
        id = str(self.parser.getParam(params, "id"))
        title = str(self.parser.getParam(params, "title"))
        url = str(self.parser.getParam(params, "url"))
       
        if id == 'None':
            self.listChannels()
        if id != 'None':
            url = self.getVideoUrl(id)
	    
	    msec = self.common.getCookieItem(COOKIEFILE, 'msec')
	    sessid = self.common.getCookieItem(COOKIEFILE, 'sessid')
	    
	    url = url + '|Cookie='+ urllib.quote_plus('msec=' + msec + '; sessid=' + sessid )
	    
    	    self.common.LOAD_AND_PLAY_VIDEO(url, title)
